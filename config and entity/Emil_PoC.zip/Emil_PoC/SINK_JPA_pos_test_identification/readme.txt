java -cp ./pubsubplus-connector-database-2.0.2-SNAPSHOT.jar -D"loader.path=./Emil_PoC/SINK_JPA_pos_test_identification/dependencies,./Emil_PoC/SINK_JPA_pos_test_identification/Config" org.springframework.boot.loader.launch.PropertiesLauncher --spring.config.additional-location="./Emil_PoC/SINK_JPA_pos_test_identification/Config/application-operator.yml"



{
    "id":"1",
    "testName":"1",
    "createdAt":"1768445690000"
}
