java -cp ./pubsubplus-connector-database-2.0.2-SNAPSHOT.jar -D"loader.path=./Emil_PoC/SINK_JPA_pos_test_metrics/dependencies,./Emil_PoC/SINK_JPA_pos_test_metrics/Config" org.springframework.boot.loader.launch.PropertiesLauncher --spring.config.additional-location="./Emil_PoC/SINK_JPA_pos_test_metrics/Config/application-operator.yml"





{
    "metricId":"2",
    "testId":"2",
    "metricName":"2",
    "metricValue":"2",
    "recordedAt":"1768446288000"
}